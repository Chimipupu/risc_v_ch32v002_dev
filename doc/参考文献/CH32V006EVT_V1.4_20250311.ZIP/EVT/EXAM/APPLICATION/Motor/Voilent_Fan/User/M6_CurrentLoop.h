/********************************** (C) COPYRIGHT *******************************
 * File Name          : M6_Currentloop.h
 * Author             : WCH
 * Version            : V1.0.0
 * Date               : 2025/01/15
 * Description        : Currentloop operation process parameter define.
*********************************************************************************
* Copyright (c) 2021 Nanjing Qinheng Microelectronics Co., Ltd.
* Attention: This software (modified or not) and binary are used for
* microcontroller manufactured by Nanjing Qinheng Microelectronics.
*******************************************************************************/
/* Define to prevent recursive inclusion ------------------------------------*/
#ifndef __M6_CURRENTLOOP_H
#define __M6_CURRENTLOOP_H

/* Includes -----------------------------------------------------------------*/
/* Exported constants -------------------------------------------------------*/
/* Exported variables -------------------------------------------------------*/
/* Exported macro -----------------------------------------------------------*/
/* Exported functions -------------------------------------------------------*/

#endif
